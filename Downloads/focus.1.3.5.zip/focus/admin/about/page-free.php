<h3><?php _e( 'Forever Free', 'focus' ) ?></h3>
<p>
	<?php _e( "Focus is a completely free WordPress theme.", 'focus' ) ?>
	<?php _e( "We'll continue developing and enhancing it for years to come.", 'focus' ) ?>
</p>