<?php
return json_decode( '{
	"85ce7a450a7ee4895f3bd823505e2e12": {
		"name": "adiraomj",
		"email": "85ce7a450a7ee4895f3bd823505e2e12",
		"loc": 638,
		"score": 59.4104571756125,
		"percent": 51.05526353305447
	},
	"b7122312e4008f8f2c76911080bca01a": {
		"name": "Andrew Misplon",
		"email": "b7122312e4008f8f2c76911080bca01a",
		"loc": 390,
		"score": 36.52296697872062,
		"percent": 31.38655706007708
	},
	"36639e6e074b731b093bde5a77305179": {
		"name": "Braam Genis",
		"email": "36639e6e074b731b093bde5a77305179",
		"loc": 366,
		"score": 18.73219756119942,
		"percent": 16.097793696710717
	},
	"a885c7bd5442dd2acd8c3e42001332c6": {
		"name": "Alex S",
		"email": "a885c7bd5442dd2acd8c3e42001332c6",
		"loc": 11,
		"score": 1.6993778249137657,
		"percent": 1.4603857101577122
	}
}', true );