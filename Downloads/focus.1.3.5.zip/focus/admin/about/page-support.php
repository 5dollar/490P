<h3><?php _e( 'Support and Documentation', 'focus' ) ?></h3>
<p>
	<?php printf( __( "Our dedicated support team is ready to help you over on our %sfree support forums%s.", 'focus' ), '<a href="https://siteorigin.com/thread/">', '</a>' ) ?>
	<?php printf( __( "You can also read through the %sFocus documentation%s to get to know it even faster.", 'focus' ), '<a href="https://siteorigin.com/focus-documentation/">', '</a>' ) ?>
</p>